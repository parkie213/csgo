https://forums.alliedmods.net/showthread.php?t=39439

Stripper can fix all kinds of bugs in maps, such as weapon models that crash the server and timed jails etc.

Extract these files to your addons/stripper/ folder after installing it.