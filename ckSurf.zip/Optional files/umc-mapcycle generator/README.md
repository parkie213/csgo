This basic tool is used to create a UMC mapcycle config for your server using information from your database.

Live version: http://koti.kapsi.fi/~mukavajoni/umc/

Basic installation instructions:
1. Upload these to files to an environment where you can run them, most likely you'll be using apache on your server
2. Set up your databases information in the config.php file
3. Run the page by entering it with your browser