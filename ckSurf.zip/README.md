
<h1>ckSurf 1.18 BETA</h1>
<p><strong>Remember to backup your database before updating to a beta version</strong></p><br />
<p><strong>Updating instructions from 1.17 -> 1.18: https://forums.alliedmods.net/showpost.php?p=2371063&postcount=841</strong><p>

<p>Alliedmods thread: https://forums.alliedmods.net/showthread.php?t=264498</p>