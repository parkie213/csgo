feel free to create new map configs like mg_.cfg
